# Binary-Search-Tree
This program performs traversing on binary tree and finds Inorder, preorder, postorder.
