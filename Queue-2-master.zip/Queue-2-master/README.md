# Queue-2
This program implements different uses of queue using concept of Linked list.
