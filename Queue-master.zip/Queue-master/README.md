# Queue
This program implements different uses of queue using concept of array.
