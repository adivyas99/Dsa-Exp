# Stack-2
This program implements different uses of stack using concept of linked list.
