# Stack
This program implements different uses of stack using concept of array.
